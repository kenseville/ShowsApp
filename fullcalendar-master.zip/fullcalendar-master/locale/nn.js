$.fullCalendar.locale("nn", {
	buttonText: {
		month: "Månad",
		week: "Veke",
		day: "Dag",
		list: "Agenda"
	},
	allDayText: "Heile dagen",
	eventLimitText: "til",
	noEventsMessage: "Ingen hendelser å vise"
});
