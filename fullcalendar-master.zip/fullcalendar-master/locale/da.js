
$.fullCalendar.locale("da", {
	buttonText: {
		month: "Måned",
		week: "Uge",
		day: "Dag",
		list: "Agenda"
	},
	allDayText: "Hele dagen",
	eventLimitText: "flere",
	noEventsMessage: "Ingen arrangementer at vise"
});
