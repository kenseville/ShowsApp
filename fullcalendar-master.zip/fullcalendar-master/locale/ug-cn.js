
$.fullCalendar.locale("ug-cn", {
	buttonText: {
		month: "ئاي",
		week: "ھەپتە",
		day: "كۈن",
		list: "كۈنتەرتىپ"
	},
	allDayText: "پۈتۈن كۈن"
});
