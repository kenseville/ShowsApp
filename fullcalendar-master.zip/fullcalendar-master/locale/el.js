
$.fullCalendar.locale("el", {
	buttonText: {
		month: "Μήνας",
		week: "Εβδομάδα",
		day: "Ημέρα",
		list: "Ατζέντα"
	},
	allDayText: "Ολοήμερο",
	eventLimitText: "περισσότερα",
	noEventsMessage: "Δεν υπάρχουν γεγονότα για να εμφανιστεί"
});
