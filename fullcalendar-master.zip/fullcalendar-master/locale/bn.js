$.fullCalendar.locale("bn", {
	buttonText: {
		month: "মাস",
		week: "সপ্তাহ",
		day: "দিন",
		list: "লিস্ট"
	},
	allDayHtml: "সারাদিন",
	eventLimitText: "আরও দেখুন",
	noEventsMessage: "কোন ইভেন্ট পাওয়া যায়নি"
});
