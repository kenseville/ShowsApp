### Bug Reports
You MUST have a JSBin recreation, or else your issue will be CLOSED without explanation.
Instructions: http://fullcalendar.io/wiki/Reporting-Bugs/

### Feature Requests
Search the issue tracker for an existing ticket before creating a new one.
Instructions: http://fullcalendar.io/wiki/Requesting-Features/

(Please erase the above text and begin typing. Thanks!)